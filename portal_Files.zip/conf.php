<?php
########################################
#	HD.rustem - configuration file
#	Yaroslav Snisar (c) 2014
#	info@rustem.com.ua
########################################
//Access information to MySQL database
$CONF_DB = array (
	'host' 		=> 'localhost', 
	'username'	=> 'host1506228_it',
	'password'	=> '0KtKkt94',
	'db_name'	=> 'host1506228_portal'
);
//System configuration variables and some options
$CONF_HD = array (
	'debug_mode'	=> false
);
?>
