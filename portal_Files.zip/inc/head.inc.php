<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <title><?=$CONF['title_header'];?></title>
    <link href="favicon.ico" type="image/ico" rel="icon" />
    <link href="favicon.ico" type="image/ico" rel="shortcut icon" />

</head>



<link rel="stylesheet" href="<?=$CONF['hostname']?>js/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="<?=$CONF['hostname']?>js/bootstrap/css/bootstrap-theme.min.css">
<link rel="stylesheet" href="<?=$CONF['hostname']?>css/jquery-ui.min.css">
<link rel="stylesheet" href="<?=$CONF['hostname']?>css/style.css?v4">
<link rel="stylesheet" href="<?=$CONF['hostname']?>css/font-awesome.min.css">
<link rel="stylesheet" href="<?=$CONF['hostname']?>js/bootstrap3-editable/css/bootstrap-editable.css">
<link rel="stylesheet" href="<?=$CONF['hostname']?>css/chosen.min.css">
<link rel="stylesheet" href="<?=$CONF['hostname']?>js/s2/select2.css?v2">
<link rel="stylesheet" href="<?=$CONF['hostname']?>js/s2/select2-bootstrap.css">
<link rel="stylesheet" href="<?=$CONF['hostname']?>css/bootstrap-datetimepicker.css">
<link rel="stylesheet" type="text/css" href="<?=$CONF['hostname']?>css/animate.css">
<style type="text/css" media="all">
    .chosen-rtl .chosen-drop { left: -9000px; }
</style>
<link rel="stylesheet" href="<?=$CONF['hostname']?>css/multi-select.css">
<link rel="stylesheet" href="<?=$CONF['hostname']?>js/daterangepicker-bs3.css">
<link rel="stylesheet" href="<?=$CONF['hostname']?>css/summernote-bs3.css">
<link rel="stylesheet" href="<?=$CONF['hostname']?>css/summernote.css">
<link rel="stylesheet" href="<?=$CONF['hostname']?>css/jquery.fileupload.css">
<link rel="stylesheet" href="<?=$CONF['hostname']?>css/jquery.fileupload-ui.css">
<link rel="stylesheet"type="text/css" media="print" href="<?=$CONF['hostname']?>css/print.css">
<body>




